$('.accordion .accordion-body').slideUp();

$(document).ready(function() {
    $('main.shop div.accordion-header').on('click', function() {
        $(this).next().slideToggle('slow');
    });

});
//toogle filter

$('.shop ').on('click', 'h2.filter-shop', function() {
    $('.sidebar ').addClass('show');
});
$('.shop .sidebar').on('click', '.close-sidebar', function() {
    setTimeout(function() {
        $('.sidebar.show ').removeClass('show')
    }, 100);
});

//dropdown menu
$('.dropdown').click(function() {
    $(this).attr('tabindex', 1).focus();
    $(this).toggleClass('active');
    $(this).find('.dropdown-menu').slideToggle(300);
});
$('.dropdown').focusout(function() {
    $(this).removeClass('active');
    $(this).find('.dropdown-menu').slideUp(300);
});
$('.dropdown .dropdown-menu li').click(function() {
    $(this).parents('.dropdown').find('span').text($(this).text());
    $(this).parents('.dropdown').find('input').attr('value', $(this).attr('id'));
});
/*End Dropdown Menu*/

/* price range */
;
(function() {
    "use strict";

    function dateFormat(date, fmt) {
        var o = {
            "M+": date.getMonth() + 1,
            "d+": date.getDate(),
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }

    var startDate = new Date("2013/11/12"),
        endDate = new Date("2013/12/22"),
        offset = endDate - startDate;

    $("#date_range").rangepicker({
        startValue: dateFormat(startDate, "yyyy/MM/dd"),
        endValue: dateFormat(endDate, "yyyy/MM/dd"),
        translateSelectLabel: function(currentPosition, totalPosition) {
            var timeOffset = offset * (currentPosition / totalPosition);
            var date = new Date(+startDate + parseInt(timeOffset));
            return dateFormat(date, "yyyy/MM/dd");
        }
    });

    $("#double_date_range").rangepicker({
        type: "double",
        startValue: dateFormat(startDate, "yyyy/MM/dd"),
        endValue: dateFormat(endDate, "yyyy/MM/dd"),
        translateSelectLabel: function(currentPosition, totalPosition) {
            var timeOffset = offset * (currentPosition / totalPosition);
            var date = new Date(+startDate + parseInt(timeOffset));
            return dateFormat(date, "yyyy/MM/dd");
        }
    });



    $("#double_number_range").rangepicker({
        type: "double",
        startValue: 500,
        endValue: 4000,
        translateSelectLabel: function(currentPosition, totalPosition) {
            return parseInt(0 * (currentPosition / totalPosition));
        }
    });




}());

$('.header-bottom ').on('click', '.mobile_menu', function() {

    if ($('.mobile_menu .slicknav_icon span').hasClass('active')) {
        $('.mobile_menu .slicknav_icon span').removeClass('rotate');
        setTimeout(function() {
            $('.mobile_menu .slicknav_icon span').removeClass('active');
        }, 300);
    } else {

        $('.mobile_menu .slicknav_icon span').addClass('active ');
        setTimeout(function() {
            $('.mobile_menu .slicknav_icon span').addClass('rotate');
        }, 300);
    }
});