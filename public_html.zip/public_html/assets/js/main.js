$(document).ready(function() {


    $('.slick-product').slick({
        dots: true,
        infinite: true,
        loop: true,
        arrows: true,
        prevArrow: '<button type="button" class=" ar-style arrow-prev"><i class="fa fa-angle-left" aria-hidden="true"></i><span class="arrow-span">Precedent</span></button>',
        nextArrow: '<button type="button" class=" ar-style arrow-next"><span class="arrow-span">Urmator</span><i class="fa fa-angle-right" aria-hidden="true"></i></button>',
        speed: 300,
        slidesToShow: 1,
        // autoplay: true,
        appendArrows: $('.arrows-slider-product'),
        appendDots: $('.slider-controls'),
        centerPadding: '500px'
    });


    /* ---- single-product----*/

    $('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav',

    });


    $('.slider-nav').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: false,
        centerMode: true,
        focusOnSelect: true,
        arrows: true,
        prevArrow: '<button type="button" class=" ar-style arrow-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></button>',
        nextArrow: '<button type="button" class=" ar-style arrow-next"><i class="fa fa-angle-right" aria-hidden="true"></i></button>',
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    centerMode: true
                }
            },
            {
                breakpoint: 420,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    centerMode: true
                }
            }
        ]
    });



    $('.slick-single-product').slick({
        dots: true,
        infinite: true,
        loop: true,
        arrows: true,
        prevArrow: '<button type="button" class=" ar-style arrow-prev"><i class="fa fa-angle-left" aria-hidden="true"></i><span class="arrow-span">Precedent</span></button>',
        nextArrow: '<button type="button" class=" ar-style arrow-next"><span class="arrow-span">Urmator</span><i class="fa fa-angle-right" aria-hidden="true"></i></button>',
        speed: 300,
        slidesToShow: 3,
        // autoplay: true,
        appendArrows: $('.arrows-slider-product'),
        appendDots: $('.slider-controls'),
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            }
        ]

    });


    $('.slick-about-product').slick({
        dots: true,
        infinite: true,
        loop: true,
        arrows: true,
        prevArrow: '<button type="button" class=" ar-style arrow-prev"><i class="fa fa-angle-left" aria-hidden="true"></i><span class="arrow-span">Precedent</span></button>',
        nextArrow: '<button type="button" class=" ar-style arrow-next"><span class="arrow-span">Urmator</span><i class="fa fa-angle-right" aria-hidden="true"></i></button>',
        speed: 300,
        slidesToShow: 5,
        autoplay: true,
        appendArrows: $('.arrows-slider-product'),
        appendDots: $('.slider-controls'),
        responsive: [{
            breakpoint: 1210,
            settings: {
                slidesToShow: 5,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                arrows: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                centerMode: true
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1

            }
        }, {
            breakpoint: 325,
            settings: {
                slidesToShow: 1
            }
        }]

    });
    /* ---- Testimonial Active----*/

    $('#testemon-carusel').slick({
        infinite: true,
        speed: 300,
        slidesToShow: 2,
        autoplay: true,
        appendDots: $('.slider-controls-testi'),
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 2,
                    infinite: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            }
        ]

    });


});



(function($) {
    "use strict"

    /*----  Proloder---- */
    $(window).on('load', function() {
        $('#preloader-active').delay(450).fadeOut('slow');
        $('body').delay(450).css({
            'overflow': 'visible'
        });
    });


    /*----  slick Nav---- */
    // mobile_menu
    var menu = $('ul#navigation');
    if (menu.length) {
        menu.slicknav({
            prependTo: ".mobile_menu",
            closedSymbol: '+',
            openedSymbol: '-'
        });
    };

    /*------Modal Window Credit---*/

    $('a[href*="#credit-card"]').on("click", function() {

        $("#modal-credit").css("display", "block");
    });

    $("#btnClose").on("click", function() {

        $("#modal-credit").css("display", "none");
    });


    /* ----- Delivery page Select Cantry----- */
    $(function() {
        new NiceCountryInput($("#example")).init();
    });





    /* ----- Nice Selectorp ----- */
    var nice_Select = $('select');
    if (nice_Select.length) {
        nice_Select.niceSelect();
    }

    /* -----  Custom Sticky Menu-----  */
    $(window).on('scroll', function() {
        var scroll = $(window).scrollTop();
        if (scroll < 245) {
            $(".header-sticky").removeClass("sticky-bar");
        } else {
            $(".header-sticky").addClass("sticky-bar");
        }
    });

    $(window).on('scroll', function() {
        var scroll = $(window).scrollTop();
        if (scroll < 245) {
            $(".header-sticky").removeClass("sticky");
        } else {
            $(".header-sticky").addClass("sticky");
        }
    });



    /* ---- sildeBar scroll ----*/
    $.scrollUp({
        scrollName: 'scrollUp', // Element ID
        topDistance: '300', // Distance from top before showing element (px)
        topSpeed: 300, // Speed back to top (ms)
        animation: 'fade', // Fade, slide, none
        animationInSpeed: 200, // Animation in speed (ms)
        animationOutSpeed: 200, // Animation out speed (ms)
        scrollText: '<i class="ti-arrow-up"></i>', // Text for element
        activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
    });





    /* ---- Mailchimp js --------*/
    function mailChimp() {
        $('#mc_embed_signup').find('form').ajaxChimp();
    }
    mailChimp();








    /* ----------------- Other Inner page Start ------------------ */



    var review = $('.client_review_slider');
    if (review.length) {
        review.owlCarousel({
            items: 1,
            loop: true,
            dots: true,
            autoplay: true,
            autoplayHoverPause: true,
            autoplayTimeout: 5000,
            nav: true,
            dots: false,
            navText: [" <i class='ti-angle-left'></i> ", "<i class='ti-angle-right'></i> "],
            responsive: {
                0: {
                    nav: false
                },
                768: {
                    nav: false
                },
                991: {
                    nav: true
                }
            }
        });
    }


    var product_slide = $('.product_img_slide');
    if (product_slide.length) {
        product_slide.owlCarousel({
            items: 1,
            loop: true,
            dots: true,
            autoplay: true,
            autoplayHoverPause: true,
            autoplayTimeout: 5000,
            nav: true,
            dots: false,
            navText: [" <i class='ti-angle-left'></i> ", "<i class='ti-angle-right'></i> "],
            responsive: {
                0: {
                    nav: false
                },
                768: {
                    nav: false
                },
                991: {
                    nav: true
                }
            }
        });
    }

    //product list slider




    var product_list_slider = $('.product_list_slider');
    if (product_list_slider.length) {
        product_list_slider.owlCarousel({
            items: 1,
            loop: true,
            dots: false,
            autoplay: true,
            autoplayHoverPause: true,
            autoplayTimeout: 5000,
            nav: true,
            navText: ["next", "previous"],
            smartSpeed: 1000,
            responsive: {
                0: {
                    margin: 15,
                    nav: false,
                    items: 1
                },
                600: {
                    margin: 15,
                    items: 1,
                    nav: false
                },
                768: {
                    margin: 30,
                    nav: true,
                    items: 1
                }
            }
        });
    }

    if ($('.img-gal').length > 0) {
        $('.img-gal').magnificPopup({
            type: 'image',
            gallery: {
                enabled: true
            }
        });
    }

    // niceSelect js code
    $(document).ready(function() {
        $('select').niceSelect();
    });

    // menu fixed js code
    $(window).scroll(function() {
        var window_top = $(window).scrollTop() + 1;
        if (window_top > 50) {
            $('.main_menu').addClass('menu_fixed animated fadeInDown');
        } else {
            $('.main_menu').removeClass('menu_fixed animated fadeInDown');
        }
    });

    // $('.counter').counterUp({
    //   time: 2000
    // });

    $('.slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        speed: 300,
        infinite: true,
        asNavFor: '.slider-nav-thumbnails',
        autoplay: true,
        pauseOnFocus: true,
        dots: true,
    });

    $('.slider-nav-thumbnails').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.slider',
        focusOnSelect: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        centerMode: true,
        responsive: [{
            breakpoint: 480,
            settings: {
                centerMode: false,
            }
        }]
    });


    // Search Toggle
    $("#search_input_box").hide();
    $("#search_1").on("click", function() {
        $("#search_input_box").slideToggle();
        $("#search_input").focus();
    });
    $("#close_search").on("click", function() {
        $('#search_input_box').slideUp(500);
    });

    //------- Mailchimp js --------//  
    function mailChimp() {
        $('#mc_embed_signup').find('form').ajaxChimp();
    }
    mailChimp();

    //------- makeTimer js --------//  
    function makeTimer() {

        //		var endTime = new Date("29 April 2018 9:56:00 GMT+01:00");	
        var endTime = new Date("27 Sep 2019 12:56:00 GMT+01:00");
        endTime = (Date.parse(endTime) / 1000);

        var now = new Date();
        now = (Date.parse(now) / 1000);

        var timeLeft = endTime - now;

        var days = Math.floor(timeLeft / 86400);
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

        if (hours < "10") {
            hours = "0" + hours;
        }
        if (minutes < "10") {
            minutes = "0" + minutes;
        }
        if (seconds < "10") {
            seconds = "0" + seconds;
        }

        $("#days").html("<span>Days</span>" + days);
        $("#hours").html("<span>Hours</span>" + hours);
        $("#minutes").html("<span>Minutes</span>" + minutes);
        $("#seconds").html("<span>Seconds</span>" + seconds);

    }
    // click counter js in card page
    (function() {

        window.inputNumber = function(el) {

            var min = el.attr('min') || false;
            var max = el.attr('max') || false;

            var els = {};

            els.dec = el.prev();
            els.inc = el.next();

            el.each(function() {
                init($(this));
            });

            function init(el) {

                els.dec.on('click', decrement);
                els.inc.on('click', increment);

                function decrement() {
                    var value = el[0].value;
                    value--;
                    if (!min || value >= min) {
                        el[0].value = value;
                    }
                }

                function increment() {
                    var value = el[0].value;
                    value++;
                    if (!max || value <= max) {
                        el[0].value = value++;
                    }
                }
            }
        }
    })();
    //display number in input
    $('.input-number').each(function() {
        inputNumber($(this));
    });



    setInterval(function() {
        makeTimer();
    }, 1000);


    $('.select_option_dropdown').hide();
    $(".select_option_list").click(function() {
        $(this).parent(".select_option").children(".select_option_dropdown").slideToggle('100');
        $(this).find(".right").toggleClass("fas fa-caret-down, fas fa-caret-up");
    });

    if ($('.new_arrival_iner').length > 0) {
        var containerEl = document.querySelector('.new_arrival_iner');
        var mixer = mixitup(containerEl);
    }


    $('.controls').on('click', function() {
        $(this).addClass('active').siblings().removeClass('active');
    });


    /* ----------------- Other Inner page End ------------------ */

    /* single product toogle nav */
    $('.subnav').on('click', '.subbtn', function() {
        if ($(this).next().css("display") == "none") {
            $('.subnav-content').fadeOut('slow');
            $(this).next().fadeIn('slow');
        } else {
            $(this).next().fadeOut('slow');
        }
    });

    $(document).on('click', function(e) {
        if (!$(e.target).closest(".navbar").length) {
            $('.subnav-content').fadeOut('slow');
        }

    });

})(jQuery);